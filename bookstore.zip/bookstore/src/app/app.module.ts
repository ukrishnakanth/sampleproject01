import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';


import { GetBooksService } from './_services/getBooks.service';
import { FeaturedComponent } from './featured/featured.component';
import { BooksComponent } from './books/books.component';
import { HighlightDirective } from './directives/highlight.directive';

@NgModule({
  declarations: [
    AppComponent,
    FeaturedComponent,
    BooksComponent,
    HighlightDirective
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [GetBooksService],
  bootstrap: [AppComponent]
})
export class AppModule { }
