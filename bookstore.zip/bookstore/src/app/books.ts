export class Books {
    kind: String;
    totalItems: Number;
    items: Array<Object>
}