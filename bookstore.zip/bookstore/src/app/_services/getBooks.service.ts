import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

import { Observable } from 'rxjs';

@Injectable()
export class GetBooksService {
    constructor(private httpClient: HttpClient) { }

    public getBooks(): any {
        return this.httpClient.get('https://www.googleapis.com/books/v1/volumes?q=HTML5');
    }

}