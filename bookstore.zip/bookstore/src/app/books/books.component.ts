import { Component, OnInit } from '@angular/core';

import { GetBooksService } from '../_services/getBooks.service';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {
  public books: any = [];
  constructor(private _getBooksService: GetBooksService) { }

  ngOnInit() {
    this.displayBooks();
  }

  displayBooks() {
    this._getBooksService.getBooks().subscribe(
      res => {
        res.items.slice(0, res.items.length - 2).forEach(element => {
          this.books.push({
            title: element.volumeInfo.title,
            subtitle: element.volumeInfo.subtitle,
            pages: element.volumeInfo.pageCount,
            authors: element.volumeInfo.authors.toString(),
            bookThumb: element.volumeInfo.imageLinks.thumbnail,
            description: element.volumeInfo.description
          })
        });
        console.log(this.books)
      })
  }

}
